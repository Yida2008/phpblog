<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title>注册 - YidaOJ</title>
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/mouse.css" />
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/head.css" />
<link rel='shortcut icon' href='http://static.spacei.top/spacei.png' /></head>
<body >
<?php
include ("nav.php");
?>
<form action="reLogin.php" method="post">
<div class="banner-box" >
    <h1><center>登录</center></h1><br>
    <h2><center><font size=3>邮箱: </font><input name="remail" type="textarea" /></center></h2><br>
    <h2><center><font size=3>密码: </font><input name="repass" type="password" /></center></h2><br>
    <center><font color=white><input type="submit"/></font>&#32;&#32;&#32;&#32;<font size=2><a href="account.php" >没有账号?点击注册</a></center></font>
</div>
</form>

</html></body>