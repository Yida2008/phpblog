<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title>首页 - YidaOJ</title>
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/mouse.css" />
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/head.css" />
<link rel='shortcut icon' href='http://static.spacei.top/spacei.png' /></head>
<body  id="home">
<?php
include ("../nav.php");
?>
<div class="window" >
    <h1><up>最新热点</up></h1><br>
    <hr><br>
    <content>
        <p>
            Space-I的OJ正在开发中，请耐心等待！<br>
            <a href="/footer.php">测试页面</a>
        </p>
    </content>
    <br>
</div>

</html></body>
