<?php
setcookie("email", '');
header("Location: /home");
?>