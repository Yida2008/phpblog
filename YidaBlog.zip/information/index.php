<?php
$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'root';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$email = $_COOKIE["email"];
$sql = 'SELECT *
        FROM useraccounts
        WHERE userEmail= "' . $email . '" ';

mysqli_select_db( $conn, 'yida_online_judge' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
$row=mysqli_fetch_array($retval);
$username=$row["userName"];
$ad=$row["isAdmin"];
// 释放内存
mysqli_free_result($retval);
mysqli_close($conn);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title><?php echo($username);?> - YidaOJ</title>
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/mouse.css" />
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/head.css" />
<link rel='shortcut icon' href='http://static.spacei.top/spacei.png' /></head>
<body >
<?php
include ("../nav.php");
?>

</html></body>
