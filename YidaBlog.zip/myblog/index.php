<?php
include ("../namecolor.php");
$email = $_COOKIE["email"];
$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'root';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sqluser = 'SELECT userName
        FROM useraccounts
        WHERE userEmail="'.$email.'"';

mysqli_select_db( $conn, 'yida_online_judge' );
$retval = mysqli_query( $conn, $sqluser );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
$rowuser=mysqli_fetch_row($retval);
if(! $rowuser ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
$username=$rowuser[0];

$sql = 'SELECT *
        FROM blogs
        WHERE BlogEmail="'.$email.'"';

//mysqli_select_db( $conn, 'yida_online_judge' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
//mysqli_select_db( $conn, 'yida_online_judge' );
$retval = mysqli_query( $conn, $sql );

$comtag='[_tags_]: - "';
$comabs='[_abstract_]: - "';
//
$poss = 0;
while($row = mysqli_fetch_row($retval)) {
    $bn[$poss]=$row[0];
    $bi[$poss]=$row[1];
    $bd[$poss]=$row[2];
    $ba[$poss]=$row[3];
    $bp[$poss]=$row[4];
    $bt[$poss]=$row[5];
    $be[$poss]=$row[6];
    //echo($poss.' ');
    $postag[$poss]=strpos($bd[$poss], $comtag);
    $posabs[$poss]=strpos($bd[$poss], $comabs);
    $tag[$poss]="";
    $abs[$poss]="";
    if($postag[$poss] != false || substr($bd[$poss], 0, 13) == $comtag) {
        $i=$postag[$poss]+strlen($comtag);
        while($bd[$poss][$i] != '"') $i++;
        $tag[$poss]=substr($bd[$poss], $postag[$poss]+strlen($comtag), $i-($postag[$poss]+strlen($comtag)));
        //echo($tag[$pos]);
        //echo($poss.' '.$i-$postag[$poss]+strlen($comtag)."<br>");
    }
    if($posabs[$poss] != false || substr($bd[$poss], 0, 17) == $comabs) {
        $i=$posabs[$poss]+strlen($comabs);
        while($bd[$poss][$i] != '"') $i++;
        //echo($posabs[$poss]+strlen($comabs).'<br>');
        $abs[$poss]=substr($bd[$poss], $posabs[$poss]+strlen($comabs), $i-($posabs[$poss]+strlen($comabs)));
        //echo($abs[$pos]."<br>");
        //echo($i.'<br>');
    }

    $sql1 = 'SELECT rating
            FROM useraccounts
            WHERE useremail="'.$be[$poss].'"';
    mysqli_select_db( $conn, 'yida_online_judge' );
    $retval1 = mysqli_query($conn, $sql1);
    if(! $retval1 ) {
        die('连接失败: ' . mysqli_error($conn));
    }
    while($row1 = mysqli_fetch_row($retval1)) {
        $br[$poss]=$row1[0];
    }
    $poss++;
}

//
$sql = 'SELECT count(*)
        FROM blogs
        WHERE BlogEmail="'.$email.'"';

mysqli_select_db( $conn, 'yida_online_judge' );
$retvalr = mysqli_query( $conn, $sql );
if(! $retvalr ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
$t=mysqli_fetch_array($retvalr);
$count=$t[0];

include ("html_table.class.php");

// create object
$mytbl = new html_table();

// General Table properties
$mytbl->width = "60%";             // set table width;
$mytbl->cellspacing = 1;         // 1 is class's default value
$mytbl->cellpadding = 4;        // 4 is class's default value
$mytbl->border = 0;             // 0 is class's default value
$mytbl->rowcolor = "blue";     // table's rows colors...default is #FFCC99

// Set table's header row
$mytbl->display_header_row = TRUE;       // enable the option. Default is FALSE
$mytbl->set_bold_labels = TRUE;             // Default is TRUE
$mytbl->set_header_font_color="#000000"; // Default is #000000
$mytbl->set_header_font_face="Tahoma";   // default is Tahoma
$mytbl->set_header_bgcolor ="#FF9933";   // Default if $FFCC33

//Set row event
$mytbl->set_row_event = TRUE; // Default is FALSE
$mytbl->set_row_event_color = "#FF9900"; //Default is #9999FF

// Set table's rows alter colors
$mytbl->set_alter_colors = TRUE;        // Default is False
$mytbl->first_alter_color = "#CCCCCC";     // Default is #FFCC99
$mytbl->second_alter_color = "#E9E9E9"; // Default is #FFFFFF

// Add Font Tags in each cell
$mytbl->display_fonts = TRUE; // Default Is FALSE


// Builbing A Table - 3 colums, 5 rows

// 1st row Colspan 3
$myarr[0][0]["colspan"]= 8;
$myarr[0][0]["align"]  = "center";
$myarr[0][0]["text"]   = "题目列表";

$myarr[1][0]["text"]= "&nbsp";
$myarr[1][0]["align"]  = "center";
$myarr[1][0]["text"]="编号";
$myarr[1][1]["align"]  = "center";
$myarr[1][1]["text"]="博客";
$myarr[1][2]["align"]  = "center";
$myarr[1][2]["text"]="类型";
$myarr[1][3]["align"]  = "center";
$myarr[1][3]["text"]="简介";
$myarr[1][4]["align"]  = "center";
$myarr[1][4]["text"]="作者";
$myarr[1][5]["align"]  = "center";
$myarr[1][5]["text"]="发表时间";
$myarr[1][6]["align"]  = "center";
$myarr[1][6]["text"]="喜爱人数";
$myarr[1][7]["align"]  = "center";
$myarr[1][7]["text"]="<a href='".'http://'.$_SERVER["HTTP_HOST"]."/blogs/edit/"."' target='_blank'>去写新的博客</a>or编辑";
##########embeded table##########################

$inner=new html_table();
$innerarr[0][0]["colspan"]=1;

for ($i=0;$i<$count;$i++) {
    $innerarr = array();
    $pos1=0;
    $pos2=0;
    $tmps=$tag[$i];
    $tmp="";
    while($pos1 < strlen($tmps)) {
        if($tmps[$pos1] == ',') {
            //echo($tmp);
            //echo($i." ".$pos2."<br>");
            $innerarr[$i][$pos2]["align"]="center";
            $innerarr[$i][$pos2++]["text"]=$tmp;
            $tmp="";
        } else $tmp = $tmp . "" . $tmps[$pos1];
        $pos1++;
    }
    if($tmp == "") continue;
    //echo($tmp);
    //echo($i." ".$pos2."<br>");
    $innerarr[$i][$pos2]["align"]="center";
    $innerarr[$i][$pos2]["text"]=$tmp;
    $innerhtml[$i]=$inner->build_html_table($innerarr);
}


####################################
// adding rows

for ($i=2; $i<$count+2; $i++){
    $tmp=$i-2;
    $title=$bn[$tmp];
    $cnt=$tmp+1;
    $myarr[$i][0]["width"] = 50;
    $myarr[$i][0]["align"] = "center";
    $myarr[$i][0]["bgcolor"] = "red";
    $myarr[$i][0]["text"]  = $tmp+1;
    $myarr[$i][1]["width"] = 200;
    $myarr[$i][1]["align"] = "center";
    $myarr[$i][1]["text"]  = "<a href='".'http://'.$_SERVER["HTTP_HOST"].'/blogs/'."?$cnt'>$title</a>";
    $myarr[$i][2]["width"] = 200;
    $myarr[$i][2]["align"] = "center";
    $myarr[$i][2]["text"]  = $innerhtml[$tmp];
    $myarr[$i][3]["width"] = 200;
    $myarr[$i][3]["align"] = "center";
    $myarr[$i][3]["text"]  = $abs[$tmp];
    //echo($tag[$tmp]);
    $myarr[$i][4]["width"] = 200;
    $myarr[$i][4]["align"] = "center";
    $myarr[$i][4]["text"]  = oncolor($br[$tmp], $ba[$tmp]);
    $myarr[$i][5]["width"] = 200;
    $myarr[$i][5]["align"] = "center";
    $myarr[$i][5]["text"]  = $bt[$tmp];
    $myarr[$i][6]["width"] = 200;
    $myarr[$i][6]["align"]  = "center";
    $myarr[$i][6]["text"]  = "<button height=9px width=12px onclick='' id='b$tmp'><img height=9px width=12px src='http://static.spacei.top/like.jpg' /></button>".$bp[$tmp];
    $myarr[$i][7]["width"] = 250;
    $myarr[$i][7]["align"]  = "center";
    $myarr[$i][7]["text"]  = "<a href='".'http://'.$_SERVER["HTTP_HOST"]."/blogs/edit/?$cnt"."' target='_blank'>编辑</a>";
}

// Building Html from array
$html = $mytbl->build_html_table( $myarr );

// 释放内存
mysqli_free_result($retval);
mysqli_close($conn);

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title><?php echo($username);?> 的博客 - YidaOJ</title>
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/mouse.css" />
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/head.css" />
<link rel='shortcut icon' href='http://static.spacei.top/spacei.png' /></head>
<body >
<?php
include ("../nav.php");
?>
<center>
<div id="all" >
<?php
    // Echo the table.
    echo($html);
?>
</div>
</center>
</html></body>
