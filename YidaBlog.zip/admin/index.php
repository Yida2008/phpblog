<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title>管理 - YidaOJ</title>
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/mouse.css" />
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/head.css" />
<link rel='shortcut icon' href='http://static.spacei.top/spacei.png' /></head>
<frameset cols="20%,80%">

  <frame src="subnav.php" />
  <frame src="main.php" />

</frameset>

</html>