<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title>管理 - YidaOJ</title>
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/mouse.css" />
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/head.css" />
<link rel='shortcut icon' href='http://static.spacei.top/spacei.png' /></head>
<body >
<ll><br>
    <i><a href="#news">新闻管理</a></i><br>
    <i><a href="#prob">题目管理</a></i><br>
    <i><a href="#auth">权限管理</a></i><br>
    <i><a href="#cont">比赛管理</a></i><br>
    <i><a href="#peop">用户管理</a></i><br>
    <i><a href="#blog">博客管理</a></i><br>
</ll>

</html></body>
