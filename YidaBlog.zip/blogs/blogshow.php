<?php
include("../namecolor.php");
$url = $_SERVER["REQUEST_URI"];
$tmp=0;
for ($i = strlen($url)-2; $i >= 0; $i--) {
    if($url[$i] == '?') {
        $tmp=$i+1;
        break;
    }
}
//echo($tmp);
$tnum=0;
$tcnt=1;
for($i=$tmp;$i<=strlen($url)-1;$i++){
    //echo($url[$i]-'0');
    $tnum+=($url[$i]-'0')*$tcnt;
    $tcnt*=10;
}
$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'root';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT *
        FROM blogs';

mysqli_select_db( $conn, 'yida_online_judge' );
$retval = mysqli_query( $conn, $sql );
//
$poss = 0;
while($row = mysqli_fetch_row($retval)) {
    if($poss == $tnum) break;
    $bn[$poss]=$row[0];
    $title=$bn[$poss];
    //echo($title);
    $bi[$poss]=$row[1];
    $bd[$poss]=$row[2];
    $ba[$poss]=$row[3];
    $bp[$poss]=$row[4];
    $bt[$poss]=$row[5];
    $be[$poss]=$row[6];
    $text=$bd[$poss];
    $person=$bp[$poss];
    $author=$ba[$poss];
    $time=$bt[$poss];
    $email=$be[$poss];
    $sql1 = 'SELECT rating
            FROM useraccounts
            WHERE useremail="'.$email.'"';
    mysqli_select_db( $conn, 'yida_online_judge' );
    $retval1 = mysqli_query($conn, $sql1);
    if(! $retval1 ) {
        die('连接失败: ' . mysqli_error($conn));
    }
    while($row1 = mysqli_fetch_row($retval1)) {
        $rating=$row1[0];
    }
    $poss++;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title><?php echo($title);?> - YidaOJ</title>
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/mouse.css" />
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/markdown.css" />
<link rel="stylesheet" type="text/css" href="http://static.spacei.top/head.css" />
<link href="https://cdn.bootcss.com/highlight.js/9.6.0/styles/atelier-lakeside-dark.min.css" rel="stylesheet"/>
<link href="http://cdn.bootcss.com/highlight.js/8.0/styles/monokai_sublime.min.css" rel="stylesheet">
<style>
#all {
    position:absolute;
    width:100%;
    margin-left: 0%;
}
</style>
<link rel='shortcut icon' href='http://static.spacei.top/spacei.png' /></head>
<body  id="blog">
<?php
//$droot="D:/Yida_Online_judge/main";
include '../nav.php';
require_once('../Parsedown.php');
header("content-type:text/html;charset=utf8");
echo("<div class='markdown'>");
echo("<div class='all'>");
?>
<h1>
<?php
echo($title);?>
</h1>
<h4>
<?php
echo("作者： ".oncolor($rating, $author));
?>
<br>
<?php echo("发表时间： ".$time);?>
<br>
<?php echo("喜爱人数： <button height=9px width=12px onclick='' id='b$tnum'><img height=12px width=12px src='http://static.spacei.top/like.jpg'></button>".$person);?>
</h4>
<hr><br>
<?php 
include "../sqlmarkdown.php";
$result = Parsedown::instance()->parse(HtmlToMarkdown($text)); 
echo str_replace(['<img ', '<code c', '">', '">'],['<img id="max" ', '<code id=code c', '"><button class="copy" id=copy>copy</button>', '/">'],$result);
echo("</div>");
echo("</div>");
?>
<br>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_HTMLorMML"></script> <script type=text/x-mathjax-config> MathJax.Hub.Config({
extensions: ["tex2jax.js"],
tex2jax: {
  inlineMath: [['$','$'], ['$$$', '$$$'], ['\\(','\\)']],
  displayMath: [['$$','$$'], ['\\[','\\]']],
  processEscapes: true,
  processEnvironments: true,
  skipTags: [
    'script',
    'style',
    'textarea',
    'input',
    ],
  ignoreClass: "CodeMirror|language-cpp|ace_editor|noJax",
  },
});
 MathJax.Hub.Queue(["Typeset", MathJax.Hub]); </script> <script>function MathUpdate(){MathJax.Hub.Queue(["Typeset",MathJax.Hub])}setInterval(MathUpdate,300)</script>
</html></body>