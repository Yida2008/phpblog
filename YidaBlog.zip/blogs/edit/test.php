<link rel="stylesheet" href="editor.md/css/editormd.min.css" />
<title>博客编辑 - YidaOJ</title>
<link href="editor.md/css/editormd.min.css" rel="stylesheet" />
<link rel='shortcut icon' href='http://static.spacei.top/spacei.png' />

<div id="editor">
    <textarea style="display:none;"></textarea>
</div>
<script src="jquery.min.js"></script>
<script src="editor.md/editormd.min.js"></script>
<script src="editor.md/lib/marked.min.js"></script>
<script src="editor.md/lib/prettify.min.js"></script>
<script src="editor.md/lib/raphael.min.js"></script>
<script src="editor.md/lib/underscore.min.js"></script>
<script src="editor.md/lib/sequence-diagram.min.js"></script>
<script src="editor.md/lib/flowchart.min.js"></script>
<script src="editor.md/lib/jquery.flowchart.min.js"></script>
<!--<script src="editor.md/editormd.js"></script>-->
<script src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_HTMLorMML'></script> <script type=text/x-mathjax-config> MathJax.Hub.Config({
    extensions: ['tex2jax.js'],
    tex2jax: {
      inlineMath: [['$','$'], ['$$$', '$$$'], ['\(','\)']],
      displayMath: [['$$','$$'], ['\[','\]']],
      processEscapes: true,
      processEnvironments: true,
      skipTags: [
        'script',
        'style',
        'textarea',
        'input',
        'code',
        ],
      ignoreClass: 'CodeMirror|language-cpp|ace_editor|noJax',
      },
    });
     MathJax.Hub.Queue(['Typeset', MathJax.Hub]); </script> 
<script>
function MathUpdate(){MathJax.Hub.Queue(['Typeset',MathJax.Hub])}setInterval(MathUpdate,300)
</script>
<script> 
    var testEditor;
    testEditor = editormd("editor", {
        mode: "gfm",          // gfm or markdown
        placeholder:'欢迎使用YidaOJ的博客',  //默认显示的文字，这里就不解释了
        width: "100%",
        height: 640,
        path: "editor.md/lib/",   //你的path路径（原资源文件中lib包在我们项目中所放的位置）
        theme: "white",//工具栏主题
        previewTheme: "white",//预览主题
        styleActiveLine: true,           // Highlight the current line
        imageUpload : true, 
        imageFormats : ["jpg","jpeg","gif","png","bmp","webp"], 
        imageUploadURL : "picture.php",//上传图片使用方法
        saveHTMLToTextarea: true,
        searchReplace : true,
        emoji: true,
        taskList: true, 
        tocm: true,         // Using [TOCM]
        flowChart: true,             // 开启流程图支持，默认关闭
        sequenceDiagram: true,       // 开启时序/序列图支持，默认关闭,
        toolbarIcons : function() {  //自定义工具栏，后面有详细介绍
            return editormd.toolbarModes['full']; // full, simple, mini
        }
    });
    $('.editormd-markdown-textarea').val();
</script>