<?php

include "../../sqlmarkdown.php";
$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'root';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names ANSI");
mysqli_select_db( $conn, 'yida_online_judge' );
$email=$_COOKIE["email"];
$title=$_POST["title"];
$text=$_POST["editor-markdown-doc"];
$id=$_POST["id"];
//die($text);
$sqlcount = "SELECT count(*)
        FROM blogs
        ";
$retvalcount = mysqli_query( $conn, $sqlcount );
if(!$retvalcount) {
    die('连接失败: ' . mysqli_error($conn));
}
$row = mysqli_fetch_row($retvalcount);
$comid = $row[0];
$sqluser = "SELECT userName
        FROM useraccounts
        WHERE userEmail='$email'";
$retvaluser = mysqli_query( $conn, $sqluser );
if(!$retvaluser) {
    die('连接失败: ' . mysqli_error($conn));
}
$rowuser = mysqli_fetch_row($retvaluser);
$user = $rowuser[0];
date_default_timezone_set('Asia/Shanghai');
$now_time= time();
$time = date('Y-m-d H:i:s',$now_time);
$text=MarkdownToHtml($text);
//die($text);
//die($text);
if($id > 0 && $id <= $comid) {
    //更改数据库
    $sql =  "UPDATE blogs
            SET BlogDescription = '$text' , BlogName='$title' , BlogTime='$time'
            WHERE BlogId=$id
            ";
    $retval = mysqli_query( $conn, $sql );
    if(! $retval ) {
        die('无法更新数据: ' . mysqli_error($conn));
    }
} else {
    $comid+=1;
    $sql = "INSERT INTO blogs ".
            "(BlogName, BlogId, BlogDescription, BlogAuthor, BlogPeople, BlogTime, BlogEmail) ".
            "VALUES ".
            "('$title','$comid','$text','$user','0','$time','$email')";
    $retval = mysqli_query( $conn, $sql );
    if(! $retval ) {
        die('无法插入数据: ' . mysqli_error($conn));
    }
}
header("Location: /blogs/");
?>