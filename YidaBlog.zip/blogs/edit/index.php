<title>博客编辑 - YidaOJ</title>
<link rel='shortcut icon' href='http://static.spacei.top/spacei.png' />
<?php
$url = $_SERVER["REQUEST_URI"];
$tmp=0;
for ($i = strlen($url)-2; $i >= 0; $i--) {
    if($url[$i] == '?') {
        $tmp=$i+1;
        break;
    }
}
//echo($tmp);
$tnum=0;
$tcnt=1;
if($tmp!=0){
    for($i=$tmp;$i<=strlen($url)-1;$i++){
        //echo($url[$i]-'0');
        $tnum+=($url[$i]-'0')*$tcnt;
        $tcnt*=10;
    }
}
$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'root';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT *
        FROM blogs';

mysqli_select_db( $conn, 'yida_online_judge' );
$retval = mysqli_query( $conn, $sql );
//
$poss = 0;
while($row = mysqli_fetch_row($retval)) {
    if($poss == $tnum) break;
    $bn[$poss]=$row[0];
    $title=$bn[$poss];
    //echo($title);
    $bi[$poss]=$row[1];
    $bd[$poss]=$row[2];
    $ba[$poss]=$row[3];
    $bp[$poss]=$row[4];
    $bt[$poss]=$row[5];
    $be[$poss]=$row[6];
    $text=$bd[$poss];
    $person=$bp[$poss];
    $author=$ba[$poss];
    $time=$bt[$poss];
    $email=$be[$poss];
    $poss++;
}
if($tmp == 0) $flag = 0;
else {
    $flag = 1;
    if($poss != $tnum || $email != $_COOKIE['email']) {
        die("您没有访问的权限，<a href='/blogs/'>点此返回博客界面</a>");
    }
}
$sql = 'SELECT count(*)
        FROM blogs';

mysqli_select_db( $conn, 'yida_online_judge' );
$retval = mysqli_query( $conn, $sql );
$row = mysqli_fetch_row($retval);
if(!$flag) $tnum = $row[0];
//echo($text);
?>

<link href="https://cdn.bootcss.com/highlight.js/9.6.0/styles/atelier-lakeside-dark.min.css" rel="stylesheet"/>
<link href="http://cdn.bootcss.com/highlight.js/8.0/styles/monokai_sublime.min.css" rel="stylesheet">
<link href="editor.md/css/editormd.css" rel="stylesheet" />




<!-- 构造form表单，以便提交数据-->
<form action="submit.php" method="POST">
    <input type="textarea" name="title" value=<?php echo('"'); if($flag) echo($title); echo('"');?> />
    <input hidden="true" name="id" value="<?php if($flag) echo($tnum); else echo($tnum+1);?>" />
    <textarea hidden="true" id="text" name="text"></textarea>
    <input type="submit" id="submit" value='提交' />
<!-- md文件编辑器编辑区域 后续js中会使用到 -->
<div id="editor">
    <textarea style="display:none;"><?php if($email == $_COOKIE["email"]) {echo($text);}?></textarea>
</div>
<script src="jquery.min.js"></script>
<script src="editor.md/editormd.js"></script>
<script src="editor.md/lib/marked.min.js"></script>
<script src="editor.md/lib/prettify.min.js"></script>
<script src="editor.md/lib/raphael.min.js"></script>
<script src="editor.md/lib/underscore.min.js"></script>
<script src="editor.md/lib/sequence-diagram.min.js"></script>
<script src="editor.md/lib/flowchart.min.js"></script>
<script src="editor.md/lib/jquery.flowchart.min.js"></script>


<script> 
    var testEditor;
    testEditor = editormd("editor", {
        mode: "markdown",          // gfm or markdown
        placeholder:'欢迎使用YidaOJ的博客',  //默认显示的文字，这里就不解释了
        width: "100%",
        height: 640,
        path: "editor.md/lib/",   //你的path路径（原资源文件中lib包在我们项目中所放的位置）
        htmlDecode : true,
        styleActiveLine: true,           // Highlight the current line
        imageUpload : true, 
        imageFormats : ["jpg","jpeg","gif","png","bmp","webp"], 
        imageUploadURL : "picture.php",//上传图片使用方法
        saveHTMLToTextarea: true,
        searchReplace : true,
        emoji: true,
        taskList: true, 
        //tocm: true,         // Using [TOCM]
        flowChart: true,             // 开启流程图支持，默认关闭
        sequenceDiagram: true,       // 开启时序/序列图支持，默认关闭,
        toolbarIcons : function() {  //自定义工具栏，后面有详细介绍
            return editormd.toolbarModes['full']; // full, simple, mini
        }
    });
    //$('.editormd-markdown-textarea').val();
</script>

</form>
<script src='http://cdn.bootcss.com/highlight.js/9.11.0/highlight.min.js'></script>
<script>hljs.initHighlightingOnLoad();</script>
<script src='http://cdn.bootcss.com/highlight.js/8.0/highlight.min.js'></script>
<script src='//cdn.bootcss.com/highlightjs-line-numbers.js/1.1.0/highlightjs-line-numbers.min.js'></script>
<script>hljs.initLineNumbersOnLoad();</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_HTMLorMML"></script> <script type=text/x-mathjax-config> MathJax.Hub.Config({
    extensions: ["tex2jax.js"],
    tex2jax: {
      inlineMath: [['$','$'], ['$$$', '$$$'], ['\\(','\\)']],
      displayMath: [['$$','$$'], ['\\[','\\]']],
      processEscapes: true,
      processEnvironments: true,
      skipTags: [
        'script',
        'style',
        'textarea',
        'input',
        ],
      ignoreClass: "CodeMirror|language-cpp|ace_editor|noJax",
      },
    });
    MathJax.Hub.Queue(["Typeset", MathJax.Hub]); </script> <script>function MathUpdate(){MathJax.Hub.Queue(["Typeset",MathJax.Hub])}setInterval(MathUpdate,300)</script>