<?php

$temp = explode(".", $_FILES["editormd-image-file"]["name"]);
$name=$temp[0];
$name=md5(uniqid($name));
$extension = $temp[1];     // 获取文件后缀名
$fileName=$name.'.'.$extension;//生成新的的文件名
        //echo "上传文件名: " . $_FILES["editormd-image-file"]["name"] . "<br>";
        //echo "文件类型: " . $_FILES["editormd-image-file"]["type"] . "<br>";
        //echo "文件大小: " . ($_FILES["editormd-image-file"]["size"] / 1024) . " kB<br>";
        //echo "文件临时存储的位置: " . $_FILES["editormd-image-file"]["tmp_name"] . "<br>";
        
        // 如果 upload 目录不存在该文件则将文件上传到 upload 目录下
move_uploaded_file($_FILES["editormd-image-file"]["tmp_name"], "D:/Yida_Online_Judge/main/api/upfile/" . $fileName);




$data['pic']='/api/upfile/'.$fileName;
//{"success":1,"url":"\/upLoadsFiles\/5bdbcb266de8d68c97328f8ccbcb946e.jpg","message":"success"} 
//这个数据格式是编辑器要求的！必须按这样返回~
//这里的success的值 必须是数值int的1或者0不然会没法回显url！1成功  0失败 
//url就是图片的路径这没啥说的，message见名知意描述啥的
echo(json_encode(['success'=>1,'url'=>$data['pic'],'message'=>'success']));

?>